package com.internousdev.webproj.action;

import com.opensymphony.xwork2.ActionSupport;

public class InquiryAction extends ActionSupport{
	public String execute() {
	       return SUCCESS;
		}
}
